const expressionInput = document.getElementById("expression");
const resultDisplay = document.getElementById("result");

expressionInput.addEventListener("input", () => {
    const expr = expressionInput.value;

    if (!/^[0-9+\-*/().\s]*$/.test(expr)) {
        resultDisplay.textContent = "Invalid characters!";
        return;
    }

    try {
        const tokens = expr.match(/(\d+\.?\d*|\+|\-|\*|\/)/g);
        if (!tokens) {
            resultDisplay.textContent = "Result: ";
            return;
        }

        let result = parseFloat(tokens[0]);
        for (let i = 1; i < tokens.length; i += 2) {
            const operator = tokens[i];
            const nextNumber = parseFloat(tokens[i + 1]);

            if (isNaN(nextNumber)) break;

            switch (operator) {
                case '+':
                    result += nextNumber;
                    break;
                case '-':
                    result -= nextNumber;
                    break;
                case '*':
                    result *= nextNumber;
                    break;
                case '/':
                    if (nextNumber === 0) {
                        resultDisplay.textContent = "Error: divide by zero";
                        return;
                    }
                    result /= nextNumber;
                    break;
                default:
                    resultDisplay.textContent = "Invalid expression";
                    return;
            }
        }

        resultDisplay.textContent = "Result: " + result;
    } catch (err) {
        resultDisplay.textContent = "Error";
    }
});
