<?php
$counterFile = "visit_count.txt";

// Create file if not exists
if (!file_exists($counterFile)) {
    file_put_contents($counterFile, "0");
}

// Increment and read visit count
$count = (int)file_get_contents($counterFile);
$count++;
file_put_contents($counterFile, $count);
$visitCount = $count;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Live Calculator</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>🔢 Live PHP Calculator</h1>
    <input type="text" id="expression" placeholder="Enter here" />
    <div class="result" id="result">Result: 0</div>
    <p class="visits">Total Visits: <strong><?= $visitCount ?></strong></p>
</div>

<script src="script.js"></script>
</body>
</html>
