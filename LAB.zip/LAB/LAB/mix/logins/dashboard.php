<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];
$users = file("users.txt", FILE_IGNORE_NEW_LINES);
foreach ($users as $line) {
    list($u, $pw, $succ, $fail, $lastSucc, $lastFail) = explode("|", $line);
    if ($u === $username) break;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>Welcome, <?php echo htmlspecialchars($username); ?>!</h2>
    <p><strong>Successful Logins:</strong> <?php echo $succ; ?></p>
    <p><strong>Last Successful Login:</strong> <?php echo $lastSucc; ?></p>
    <p><strong>Unsuccessful Logins:</strong> <?php echo $fail; ?></p>
    <p><strong>Last Unsuccessful Login:</strong> <?php echo $lastFail; ?></p>
    <a href="logout.php" class="back">Logout</a>
</div>
</body>
</html>
