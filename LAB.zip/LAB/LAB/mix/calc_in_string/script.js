let expression = "";        // Real expression for eval (e.g. 1+2)
let wordExpression = "";    // Word version (e.g. one plus two)

function append(char) {
  expression += char;
  wordExpression += toWord(char) + " ";
  document.getElementById("input").value = wordExpression.trim();
}

function clearAll() {
  expression = "";
  wordExpression = "";
  document.getElementById("input").value = "";
  document.getElementById("output").value = "";
}

function calculate() {
  try {
    let result = eval(expression);
    document.getElementById("output").value = result;
  } catch (e) {
    document.getElementById("output").value = "Error";
  }
}

function toWord(char) {
  const words = {
    '0': 'zero',
    '1': 'one',
    '2': 'two',
    '3': 'three',
    '4': 'four',
    '5': 'five',
    '6': 'six',
    '7': 'seven',
    '8': 'eight',
    '9': 'nine',
    '+': 'plus',
    '-': 'minus',
    '*': 'times',
    '/': 'divided by'
  };
  return words[char] || '';
}
