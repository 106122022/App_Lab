<?php
// File paths
$counterFile = 'access_counter.txt';
$reviewFile = 'reviews.txt';

// Initialize files if not present
if (!file_exists($counterFile)) file_put_contents($counterFile, "0");
if (!file_exists($reviewFile)) file_put_contents($reviewFile, "");

// Increment visit count
$visit_count = (int)file_get_contents($counterFile);
$visit_count++;
file_put_contents($counterFile, $visit_count);

// Count number of reviews
$reviews = file($reviewFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$total_reviews = count($reviews);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Book Review Portal</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f3f3f3;
            text-align: center;
            margin-top: 50px;
        }

        h2 {
            color: #2c3e50;
        }

        form {
            background: white;
            padding: 30px;
            border-radius: 10px;
            display: inline-block;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.2);
        }

        input, textarea {
            width: 300px;
            padding: 10px;
            margin: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        input[type="submit"] {
            background: #27ae60;
            color: white;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }

        input[type="submit"]:hover {
            background: #219150;
        }

        .counter {
            margin-bottom: 30px;
            color: #555;
        }
    </style>

    <script>
        window.onload = function () {
            let totalReviews = <?php echo $total_reviews; ?>;
            if (totalReviews > 5 || totalReviews < 0) {
                alert("Number of reviews is out of expected range: " + totalReviews);
            }
        };

        function validateForm() {
            const rating = document.forms["reviewForm"]["rating"].value;
            if (rating < 1 || rating > 5) {
                alert("Rating must be between 1 and 5.");
                return false;
            }
            return true;
        }
    </script>
</head>
<body>
    <h2>📚 Welcome to the Book Review Page</h2>

    <div class="counter">
        <p>This page has been accessed <strong><?php echo $visit_count; ?></strong> times.</p>
        <p>There are currently <strong><?php echo $total_reviews; ?></strong> reviews submitted.</p>
    </div>

    <form name="reviewForm" method="post" action="submit_review.php" onsubmit="return validateForm()">
        <input type="text" name="name" placeholder="Your Name" required><br>
        <textarea name="review" placeholder="Write your review..." required></textarea><br>
        <input type="number" name="rating" placeholder="Rating (1-5)" required><br>
        <input type="submit" value="Submit Review">
    </form>
</body>
</html>
