<?php
$reviewFile = 'reviews.txt';

$name = htmlspecialchars($_POST['name']);
$review = htmlspecialchars($_POST['review']);
$rating = intval($_POST['rating']);

// Prepare the data to be saved
$entry = "$name | Rating: $rating | Review: $review | Date: " . date("Y-m-d H:i:s") . PHP_EOL;

// Append to file
file_put_contents($reviewFile, $entry, FILE_APPEND);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Review Submitted</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #ecf0f1;
            text-align: center;
            padding-top: 100px;
        }

        .message-box {
            background: white;
            display: inline-block;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
        }

        .message-box h2 {
            color: #2c3e50;
        }

        .back-btn {
            margin-top: 20px;
            padding: 10px 20px;
            background: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            font-size: 16px;
        }

        .back-btn:hover {
            background: #2980b9;
        }
    </style>
</head>
<body>
    <div class="message-box">
        <h2>✅ <?php echo $name; ?> has successfully submitted a review!</h2>
        <a class="back-btn" href="index.php">⬅️ Back to Review Page</a>
    </div>
</body>
</html>
