function append(value) {
    document.getElementById("input").value += value;
  }
  
  function clearInput() {
    document.getElementById("input").value = "";
    document.getElementById("output").value = "";
  }
  
  function calculate() {
    const input = document.getElementById("input").value;
    let result;
  
    try {
      result = eval(input); // safe for controlled input
    } catch (e) {
      document.getElementById("output").value = "Invalid expression";
      return;
    }
  
    const stringResult = result.toString().split('').map(digitToWord).join(' ');
    document.getElementById("output").value = stringResult;
  }
  
  function digitToWord(digit) {
    const map = {
      '0': 'zero',
      '1': 'one',
      '2': 'two',
      '3': 'three',
      '4': 'four',
      '5': 'five',
      '6': 'six',
      '7': 'seven',
      '8': 'eight',
      '9': 'nine',
      '-': 'minus',
      '.': 'point'
    };
    return map[digit] || '';
  }
  