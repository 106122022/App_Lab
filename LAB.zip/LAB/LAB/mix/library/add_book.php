<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title = trim($_POST["title"]);
    $author = trim($_POST["author"]);

    if ($title && $author) {
        file_put_contents("data/books.txt", "$title|$author|available\n", FILE_APPEND);
        $message = "Book added successfully!";
    } else {
        $message = "Please enter all fields.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Book</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="container">
    <h2>➕ Add New Book</h2>
    <?php if (isset($message)) echo "<p class='info'>$message</p>"; ?>
    <form method="POST">
        <input type="text" name="title" placeholder="Book Title" required><br>
        <input type="text" name="author" placeholder="Author" required><br>
        <button type="submit">Add Book</button>
    </form>
    <a href="book.php" class="back">← Back</a>
</div>
</body>
</html>
