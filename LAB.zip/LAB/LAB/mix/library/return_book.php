<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title = trim($_POST["title"]);
    $books = file("data/books.txt");
    $updatedBooks = [];
    $found = false;

    foreach ($books as $line) {
        list($bookTitle, $author, $status) = explode("|", trim($line));
        if ($title === $bookTitle && trim($status) === "borrowed") {
            $updatedBooks[] = "$bookTitle|$author|available\n";
            $found = true;
        } else {
            $updatedBooks[] = $line;
        }
    }

    file_put_contents("data/books.txt", implode("", $updatedBooks));
    $message = $found ? "Book returned successfully!" : "Book not found or wasn't borrowed.";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Return Book</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="container">
    <h2>📤 Return Book</h2>
    <?php if (isset($message)) echo "<p class='info'>$message</p>"; ?>
    <form method="POST">
        <input type="text" name="title" placeholder="Book Title" required><br>
        <button type="submit">Return</button>
    </form>
    <a href="book.php" class="back">← Back</a>
</div>
</body>
</html>
