<!DOCTYPE html>
<html>
<head>
    <title>Library Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="container">
    <h1>📚 Library Management</h1>
    <a href="add_book.php" class="btn">➕ Add Book</a>
    <a href="view_books.php" class="btn">📖 View Books</a>
    <a href="borrow_book.php" class="btn">📥 Borrow Book</a>
    <a href="return_book.php" class="btn">📤 Return Book</a>
</div>
</body>
</html>
