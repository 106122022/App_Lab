<?php
session_start();
$username = trim($_POST['username']);
$password = $_POST['password'];

$usersFile = "users.txt";
$lines = file($usersFile, FILE_IGNORE_NEW_LINES);
$found = false;

foreach ($lines as $i => $line) {
    list($u, $pw, $succ, $fail, $lastSucc, $lastFail) = explode("|", $line);

    if ($u === $username) {
        $found = true;
        if (password_verify($password, $pw)) {
            $succ++;
            $lastSucc = date("Y-m-d H:i:s");
            $_SESSION['username'] = $username;
            $lines[$i] = "$u|$pw|$succ|$fail|$lastSucc|$lastFail";
            file_put_contents($usersFile, implode("\n", $lines) . "\n");
            header("Location: book.php");
            exit();
        } else {
            $fail++;
            $lastFail = date("Y-m-d H:i:s");
            $lines[$i] = "$u|$pw|$succ|$fail|$lastSucc|$lastFail";
            file_put_contents($usersFile, implode("\n", $lines) . "\n");
            $_SESSION['error'] = "Incorrect password.";
            header("Location: login.php");
            exit();
        }
    }
}

if (!$found) {
    $_SESSION['error'] = "User does not exist.";
    header("Location: login.php");
}
