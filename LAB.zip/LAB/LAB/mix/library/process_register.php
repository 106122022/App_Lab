<?php
session_start();

$username = trim($_POST['username']);
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

$usersFile = "users.txt";
$users = file($usersFile, FILE_IGNORE_NEW_LINES);
foreach ($users as $user) {
    list($u) = explode("|", $user);
    if ($u === $username) {
        $_SESSION['error'] = "Username already exists!";
        header("Location: register.php");
        exit();
    }
}

$newLine = $username . "|" . $password . "|0|0|NA|NA\n";  // username|hashed_pw|succ|fail|last_succ|last_fail
file_put_contents($usersFile, $newLine, FILE_APPEND);

$_SESSION['registered'] = true;
header("Location: register.php");
