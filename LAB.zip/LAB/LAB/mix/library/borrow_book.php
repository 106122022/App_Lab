<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title = trim($_POST["title"]);
    $books = file("data/books.txt");
    $updatedBooks = [];
    $found = false;

    foreach ($books as $line) {
        list($bookTitle, $author, $status) = explode("|", trim($line));
        if ($title === $bookTitle && trim($status) === "available") {
            $updatedBooks[] = "$bookTitle|$author|borrowed\n";
            file_put_contents("data/borrowed.txt", "$bookTitle|$author\n", FILE_APPEND);
            $found = true;
        } else {
            $updatedBooks[] = $line;
        }
    }

    file_put_contents("data/books.txt", implode("", $updatedBooks));
    $message = $found ? "Book borrowed successfully!" : "Book not available or doesn't exist.";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Borrow Book</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="container">
    <h2>📥 Borrow Book</h2>
    <?php if (isset($message)) echo "<p class='info'>$message</p>"; ?>
    <form method="POST">
        <input type="text" name="title" placeholder="Book Title" required><br>
        <button type="submit">Borrow</button>
    </form>
    <a href="book.php" class="back">← Back</a>
</div>
</body>
</html>
