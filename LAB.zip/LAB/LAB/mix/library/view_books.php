<?php
$books = file_exists("data/books.txt") ? file("data/books.txt") : [];
?>
<!DOCTYPE html>
<html>
<head>
    <title>All Books</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>📖 Available Books</h2>
    <?php if (count($books) === 0): ?>
        <p>No books found.</p>
    <?php else: ?>
        <ul>
            <?php foreach ($books as $book): 
                list($title, $author, $status) = explode("|", trim($book));
            ?>
                <li><strong><?= htmlspecialchars($title) ?></strong> by <?= htmlspecialchars($author) ?> - <em><?= $status ?></em></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
    <a href="book.php" class="back">← Back</a>
</div>
</body>
</html>
