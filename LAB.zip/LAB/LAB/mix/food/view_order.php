<?php
session_start();
$orderData = file_exists("orders.txt") ? unserialize(file_get_contents("orders.txt")) : null;
?>
<!DOCTYPE html>
<html>
<head>
    <title>View Order</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <?php if ($orderData): ?>
        <h2>🧾 Your Order</h2>
        <p><strong>Ordered at:</strong> <?= $orderData['time'] ?></p>
        <p><strong>Estimated Delivery:</strong> <?= $orderData['deliveryTime'] ?></p>
        <ul>
            <?php foreach ($orderData['items'] as $item): ?>
                <li><?= htmlspecialchars($item) ?></li>
            <?php endforeach; ?>
        </ul>
        <a href="cancel_order.php" class="btn danger">Cancel Order</a>
        <a href="index.php" class="btn">Back to Menu</a>
    <?php else: ?>
        <p>No order found.</p>
        <a href="index.php" class="btn">Go to Menu</a>
    <?php endif; ?>
</div>
</body>
</html>
