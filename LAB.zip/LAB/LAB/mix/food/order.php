<?php session_start();

$menu = [
    "Pizza" => 150,
    "Burger" => 80,
    "Pasta" => 120,
    "Sandwich" => 60,
    "Coffee" => 40
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['items'])) {
        $_SESSION['error'] = "Please select at least one item!";
        header("Location: index.php");
        exit();
    }

    $_SESSION['order'] = $_POST['items'];
    $_SESSION['order_time'] = date("H:i:s");
    $_SESSION['estimated_time'] = date("H:i:s", time() + 30 * 60); // 30 mins
}

$orderItems = $_SESSION['order'] ?? [];

$total = 0;
?>
<!DOCTYPE html>
<html>
<head>
    <title>Your Order</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>🧾 Your Order Summary</h2>
    <?php if (empty($orderItems)): ?>
        <p>No order placed yet.</p>
    <?php else: ?>
        <ul>
            <?php foreach ($orderItems as $item): ?>
                <li><?= $item ?> - ₹<?= $menu[$item] ?></li>
                <?php $total += $menu[$item]; ?>
            <?php endforeach; ?>
        </ul>
        <p><strong>Total:</strong> ₹<?= $total ?></p>
        <p><strong>Order Time:</strong> <?= $_SESSION['order_time'] ?></p>
        <p><strong>Estimated Delivery:</strong> <?= $_SESSION['estimated_time'] ?></p>
    <?php endif; ?>
    <br>
    <a href="index.php" class="back">⬅️ Back to Menu</a>
</div>
</body>
</html>
