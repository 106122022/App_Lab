<?php
session_start();
unset($_SESSION['order']);
unset($_SESSION['order_time']);
unset($_SESSION['estimated_time']);

header("Location: index.php");
exit();
