<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Food Menu</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>🍽️ Food Menu</h2>

    <form method="POST" action="order.php">
        <label><input type="checkbox" name="items[]" value="Pizza"> Pizza - ₹150</label><br>
        <label><input type="checkbox" name="items[]" value="Burger"> Burger - ₹80</label><br>
        <label><input type="checkbox" name="items[]" value="Pasta"> Pasta - ₹120</label><br>
        <label><input type="checkbox" name="items[]" value="Sandwich"> Sandwich - ₹60</label><br>
        <label><input type="checkbox" name="items[]" value="Coffee"> Coffee - ₹40</label><br><br>

        <button type="submit">Place Order</button>
    </form>

    <br>
    <form action="order.php" method="GET">
        <button type="submit">View Order</button>
    </form>

    <?php if (isset($_SESSION['order'])): ?>
        <form action="cancel.php" method="POST">
            <button type="submit" class="cancel">Cancel Order</button>
        </form>
    <?php endif; ?>
</div>
</body>
</html>
        