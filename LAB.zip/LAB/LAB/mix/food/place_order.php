<?php
session_start();
if (isset($_POST['items'])) {
    $items = $_POST['items'];
    $time = date("H:i:s");
    $deliveryTime = date("H:i:s", strtotime("+30 minutes"));

    $order = [
        "items" => $items,
        "time" => $time,
        "deliveryTime" => $deliveryTime
    ];

    file_put_contents("orders.txt", serialize($order));
    $_SESSION['order_placed'] = true;
    header("Location: view_order.php");
} else {
    $_SESSION['error'] = "Please select at least one item!";
    header("Location: index.php");
}
?>
