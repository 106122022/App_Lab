<?php
// === Counter Logic ===
$counterFile = "counter.txt";
if (!file_exists($counterFile)) {
    file_put_contents($counterFile, 0);
}
$count = (int)file_get_contents($counterFile);
$count++;
file_put_contents($counterFile, $count);

// === Review Submission Logic ===
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = htmlspecialchars($_POST["name"]);
    $review = htmlspecialchars($_POST["review"]);

    $entry = "Name: $name\nReview: $review\n---\n";
    file_put_contents("reviews.txt", $entry, FILE_APPEND);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Book Review Site</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f7f7f7;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            max-width: 500px;
            margin: auto;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        textarea, input {
            width: 100%;
            margin: 10px 0;
            padding: 10px;
        }
        .counter {
            font-size: 14px;
            color: gray;
            text-align: right;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Leave a Book Review</h2>
    <form method="POST">
        <input type="text" name="name" placeholder="Your Name" required>
        <textarea name="review" rows="4" placeholder="Your Review..." required></textarea>
        <button type="submit">Submit Review</button>
    </form>

    <div class="counter">
        This site has been accessed <strong><?php echo $count; ?></strong> times.
    </div>
</div>
</body>
</html>
