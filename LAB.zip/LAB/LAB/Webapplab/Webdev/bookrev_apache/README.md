Awesome — if you’re using **Windows**, here’s how it works instead 👇

---

### 🪟 Hosting with Apache on Windows

If you’ve installed **Apache** using:
- **XAMPP** ✅ (most common)
- or **WAMP**, **manual Apache install**

then the default directory is **different** from Linux.

---

### ✅ If you're using **XAMPP**:

Your default Apache document root is:

```
C:\xampp\htdocs
```

So if you put your project in:

```
C:\xampp\htdocs\review-site\
```

Then you can access it by opening your browser and going to:

```
http://localhost/review-site/
```

---

### ✅ If you're using **WAMP**:

Your document root will usually be:

```
C:\wamp64\www
```

So you'd place your files here:

```
C:\wamp64\www\review-site\
```

And visit:

```
http://localhost/review-site/
```

---

### 📝 Summary of folder paths:

| Platform | Apache Folder |
|----------|----------------|
| Ubuntu/Linux | `/var/www/html/` |
| Windows (XAMPP) | `C:\xampp\htdocs\` |
| Windows (WAMP) | `C:\wamp64\www\` |

---

Let me know which one you're using — I can help you set it up step by step if needed!