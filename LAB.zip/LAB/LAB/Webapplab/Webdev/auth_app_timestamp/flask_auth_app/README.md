# Flask Login-Signup Web App with Login Timestamp Tracking

## 🔐 Features
- User signup and login
- Stores:
  - Last successful login timestamp
  - Last failed login attempt timestamp
- SQLite backend
- Simple CSS styling

## 🚀 How to Run

```bash
# Set up virtual environment
cd flask_auth_app
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install flask

# Run app
python app.py

