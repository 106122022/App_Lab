#!/bin/bash

# Create folders
mkdir -p flask_auth_app/templates
mkdir -p flask_auth_app/static
cd flask_auth_app

# app.py
cat <<'EOF' > app.py
from flask import Flask, render_template, request, redirect, session, flash
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'supersecretkey'

def init_db():
    with sqlite3.connect('users.db') as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                last_success TEXT,
                last_fail TEXT
            )
        ''')

@app.route('/')
def home():
    return redirect('/login')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        with sqlite3.connect('users.db') as conn:
            try:
                conn.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
                conn.commit()
                flash('Signup successful. Please login.', 'success')
                return redirect('/login')
            except:
                flash('Username already exists.', 'danger')
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        with sqlite3.connect('users.db') as conn:
            user = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
            if user and user[2] == password:
                conn.execute("UPDATE users SET last_success = ? WHERE id = ?", (datetime.now(), user[0]))
                conn.commit()
                session['user'] = username
                return redirect('/dashboard')
            else:
                if user:
                    conn.execute("UPDATE users SET last_fail = ? WHERE id = ?", (datetime.now(), user[0]))
                    conn.commit()
                flash('Login failed.', 'danger')
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect('/login')
    with sqlite3.connect('users.db') as conn:
        user = conn.execute("SELECT * FROM users WHERE username = ?", (session['user'],)).fetchone()
    return render_template('dashboard.html', user=user)

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect('/login')

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
EOF

# style.css
cat <<'EOF' > static/style.css
body {
    font-family: Arial, sans-serif;
    background-color: #f2f2f2;
    padding: 20px;
    text-align: center;
}

.container {
    background-color: white;
    padding: 20px;
    border-radius: 8px;
    width: 300px;
    margin: auto;
    box-shadow: 0 0 10px #ccc;
}

input {
    width: 90%;
    padding: 10px;
    margin: 10px 0;
}

button {
    padding: 10px 20px;
    margin-top: 10px;
}
EOF

# login.html
cat <<'EOF' > templates/login.html
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="/static/style.css">
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <form method="post">
            <input name="username" placeholder="Username" required><br>
            <input name="password" type="password" placeholder="Password" required><br>
            <button type="submit">Login</button>
        </form>
        <p><a href="/signup">New user? Signup</a></p>
        {% with messages = get_flashed_messages(with_categories=true) %}
          {% if messages %}
            {% for category, message in messages %}
              <p style="color: red;">{{ message }}</p>
            {% endfor %}
          {% endif %}
        {% endwith %}
    </div>
</body>
</html>
EOF

# signup.html
cat <<'EOF' > templates/signup.html
<!DOCTYPE html>
<html>
<head>
    <title>Signup</title>
    <link rel="stylesheet" href="/static/style.css">
</head>
<body>
    <div class="container">
        <h2>Signup</h2>
        <form method="post">
            <input name="username" placeholder="Username" required><br>
            <input name="password" type="password" placeholder="Password" required><br>
            <button type="submit">Signup</button>
        </form>
        <p><a href="/login">Already have an account? Login</a></p>
        {% with messages = get_flashed_messages(with_categories=true) %}
          {% if messages %}
            {% for category, message in messages %}
              <p style="color: red;">{{ message }}</p>
            {% endfor %}
          {% endif %}
        {% endwith %}
    </div>
</body>
</html>
EOF

# dashboard.html
cat <<'EOF' > templates/dashboard.html
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="/static/style.css">
</head>
<body>
    <div class="container">
        <h2>Welcome {{ user[1] }}</h2>
        <p>✅ Last Successful Login: {{ user[3] or "N/A" }}</p>
        <p>❌ Last Failed Login: {{ user[4] or "N/A" }}</p>
        <p><a href="/logout">Logout</a></p>
    </div>
</body>
</html>
EOF

# README.md
cat <<'EOF' > README.md
# Flask Login-Signup Web App with Login Timestamp Tracking

## 🔐 Features
- User signup and login
- Stores:
  - Last successful login timestamp
  - Last failed login attempt timestamp
- SQLite backend
- Simple CSS styling

## 🚀 How to Run

```bash
# Set up virtual environment
cd flask_auth_app
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install flask

# Run app
python app.py

EOF