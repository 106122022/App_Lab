from flask import Flask, render_template, request, redirect
import sqlite3
from datetime import datetime

app = Flask(__name__)

def init_db():
    with sqlite3.connect('reviews.db') as conn:
        conn.execute('''CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            review TEXT NOT NULL,
            timestamp TEXT NOT NULL
        )''')
        conn.execute('''CREATE TABLE IF NOT EXISTS visits (
            id INTEGER PRIMARY KEY,
            count INTEGER DEFAULT 0
        )''')
        conn.execute('INSERT OR IGNORE INTO visits (id, count) VALUES (1, 0)')

@app.route('/', methods=['GET', 'POST'])
def index():
    with sqlite3.connect('reviews.db') as conn:
        if request.method == 'POST':
            name = request.form['name']
            review = request.form['review']
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            conn.execute('INSERT INTO reviews (name, review, timestamp) VALUES (?, ?, ?)',
                         (name, review, timestamp))
            return redirect('/')
        else:
            conn.execute('UPDATE visits SET count = count + 1 WHERE id = 1')

        reviews = conn.execute('SELECT * FROM reviews ORDER BY id DESC').fetchall()
        count = conn.execute('SELECT count FROM visits WHERE id = 1').fetchone()[0]
    return render_template('index.html', reviews=reviews, count=count)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
