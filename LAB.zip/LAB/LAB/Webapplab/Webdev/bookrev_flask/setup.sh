#!/bin/bash

# Create folder structure
mkdir -p book_review_site/templates
mkdir -p book_review_site/static

cd book_review_site

# Create app.py
cat <<'EOF' > app.py
from flask import Flask, render_template, request, redirect
import sqlite3
from datetime import datetime

app = Flask(__name__)

def init_db():
    with sqlite3.connect('reviews.db') as conn:
        conn.execute('''CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            review TEXT NOT NULL,
            timestamp TEXT NOT NULL
        )''')
        conn.execute('''CREATE TABLE IF NOT EXISTS visits (
            id INTEGER PRIMARY KEY,
            count INTEGER DEFAULT 0
        )''')
        conn.execute('INSERT OR IGNORE INTO visits (id, count) VALUES (1, 0)')

@app.route('/', methods=['GET', 'POST'])
def index():
    with sqlite3.connect('reviews.db') as conn:
        conn.execute('UPDATE visits SET count = count + 1 WHERE id = 1')
        if request.method == 'POST':
            name = request.form['name']
            review = request.form['review']
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            conn.execute('INSERT INTO reviews (name, review, timestamp) VALUES (?, ?, ?)',
                         (name, review, timestamp))
            return redirect('/')
        reviews = conn.execute('SELECT * FROM reviews ORDER BY id DESC').fetchall()
        count = conn.execute('SELECT count FROM visits WHERE id = 1').fetchone()[0]
    return render_template('index.html', reviews=reviews, count=count)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
EOF

# Create templates/index.html
cat <<'EOF' > templates/index.html
<!DOCTYPE html>
<html>
<head>
    <title>Book Review Site</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
</head>
<body>
    <div class="container">
        <h1>Book Review Form</h1>
        <form method="POST">
            <input type="text" name="name" placeholder="Your Name" required><br>
            <textarea name="review" placeholder="Write your review..." required></textarea><br>
            <button type="submit">Submit</button>
        </form>
        <p>Page visited {{ count }} times.</p>

        <h2>All Reviews</h2>
        {% for r in reviews %}
            <div class="review">
                <p><strong>{{ r[1] }}</strong> ({{ r[3] }})</p>
                <p>{{ r[2] }}</p>
            </div>
        {% endfor %}
    </div>
</body>
</html>
EOF

# Create static/style.css
cat <<'EOF' > static/style.css
body {
    font-family: Arial, sans-serif;
    background-color: #f5f5f5;
    padding: 20px;
}

.container {
    background: white;
    padding: 20px;
    max-width: 600px;
    margin: auto;
    border-radius: 10px;
}

input, textarea {
    width: 100%;
    margin: 10px 0;
    padding: 10px;
    box-sizing: border-box;
}

button {
    padding: 10px 15px;
    background-color: #28a745;
    color: white;
    border: none;
    cursor: pointer;
}

.review {
    margin-top: 20px;
    padding: 10px;
    border-top: 1px solid #ccc;
}
EOF

# Final message
echo "✅ Flask project created in 'book_review_site/'"
echo ""
echo "👉 Next steps:"
echo "1. Navigate to the folder:"
echo "   cd book_review_site"
echo ""
echo "2. (Optional) Create a virtual environment and activate it:"
echo "   python3 -m venv venv"
echo "   source venv/bin/activate"
echo ""
echo "3. Install Flask:"
echo "   pip install Flask"
echo ""
echo "4. Run the app:"
echo "   python app.py"
echo ""
echo "Then open your browser and go to: http://127.0.0.1:5000"
