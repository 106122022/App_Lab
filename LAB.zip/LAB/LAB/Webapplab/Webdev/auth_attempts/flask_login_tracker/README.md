# Flask Login-Signup Tracker Web App

This app allows user authentication and tracks the number of successful and unsuccessful login attempts per user.

---

## 🖥️ Features

- User Signup & Login
- SQLite database
- Tracks:
  - Number of successful logins
  - Number of failed logins
- Apache deployable with `mod_wsgi`

---

## ⚙️ How to Run

### 🐧 On Ubuntu

```bash
# Setup virtual environment
cd flask_login_tracker
python3 -m venv venv
source venv/bin/activate

# Install Flask
pip install flask

# Run the app
python app.py
