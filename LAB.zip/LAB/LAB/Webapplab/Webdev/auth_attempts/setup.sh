#!/bin/bash

# Create folders
mkdir -p flask_login_tracker/templates
mkdir -p flask_login_tracker/static
cd flask_login_tracker

# app.py
cat <<'EOF' > app.py
from flask import Flask, render_template, request, redirect, session, flash
import sqlite3

app = Flask(__name__)
app.secret_key = 'secret123'

def init_db():
    with sqlite3.connect('users.db') as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                success_count INTEGER DEFAULT 0,
                fail_count INTEGER DEFAULT 0
            )
        ''')

@app.route('/')
def home():
    return redirect('/login')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        with sqlite3.connect('users.db') as conn:
            try:
                conn.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
                flash('Signup successful. Please login.', 'success')
                return redirect('/login')
            except:
                flash('Username already exists.', 'danger')
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        with sqlite3.connect('users.db') as conn:
            user = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
            if user and user[2] == password:
                conn.execute("UPDATE users SET success_count = success_count + 1 WHERE id = ?", (user[0],))
                conn.commit()
                session['user'] = username
                return redirect('/dashboard')
            else:
                if user:
                    conn.execute("UPDATE users SET fail_count = fail_count + 1 WHERE id = ?", (user[0],))
                    conn.commit()
                flash('Login failed.', 'danger')
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect('/login')
    with sqlite3.connect('users.db') as conn:
        user = conn.execute("SELECT * FROM users WHERE username = ?", (session['user'],)).fetchone()
    return render_template('dashboard.html', user=user)

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect('/login')

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
EOF

# style.css
cat <<'EOF' > static/style.css
body {
    font-family: Arial, sans-serif;
    background-color: #f5f5f5;
    text-align: center;
    padding: 40px;
}
.container {
    background-color: white;
    border-radius: 8px;
    padding: 20px;
    width: 300px;
    margin: auto;
    box-shadow: 0 0 10px gray;
}
input, button {
    width: 90%;
    margin: 10px 0;
    padding: 10px;
}
EOF

# login.html
cat <<'EOF' > templates/login.html
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="/static/style.css">
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <form method="post">
            <input name="username" placeholder="Username" required><br>
            <input name="password" type="password" placeholder="Password" required><br>
            <button type="submit">Login</button>
        </form>
        <p><a href="/signup">No account? Signup</a></p>
        {% with messages = get_flashed_messages(with_categories=true) %}
          {% if messages %}
            {% for category, message in messages %}
              <p style="color: red;">{{ message }}</p>
            {% endfor %}
          {% endif %}
        {% endwith %}
    </div>
</body>
</html>
EOF

# signup.html
cat <<'EOF' > templates/signup.html
<!DOCTYPE html>
<html>
<head>
    <title>Signup</title>
    <link rel="stylesheet" href="/static/style.css">
</head>
<body>
    <div class="container">
        <h2>Signup</h2>
        <form method="post">
            <input name="username" placeholder="Username" required><br>
            <input name="password" type="password" placeholder="Password" required><br>
            <button type="submit">Signup</button>
        </form>
        <p><a href="/login">Already have an account? Login</a></p>
        {% with messages = get_flashed_messages(with_categories=true) %}
          {% if messages %}
            {% for category, message in messages %}
              <p style="color: red;">{{ message }}</p>
            {% endfor %}
          {% endif %}
        {% endwith %}
    </div>
</body>
</html>
EOF

# dashboard.html
cat <<'EOF' > templates/dashboard.html
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="/static/style.css">
</head>
<body>
    <div class="container">
        <h2>Welcome {{ user[1] }}</h2>
        <p>✅ Successful Logins: {{ user[3] }}</p>
        <p>❌ Failed Logins: {{ user[4] }}</p>
        <p><a href="/logout">Logout</a></p>
    </div>
</body>
</html>
EOF

# README.md
cat <<'EOF' > README.md
# Flask Login-Signup Tracker Web App

This app allows user authentication and tracks the number of successful and unsuccessful login attempts per user.

---

## 🖥️ Features

- User Signup & Login
- SQLite database
- Tracks:
  - Number of successful logins
  - Number of failed logins
- Apache deployable with `mod_wsgi`

---

## ⚙️ How to Run

### 🐧 On Ubuntu

```bash
# Setup virtual environment
cd flask_login_tracker
python3 -m venv venv
source venv/bin/activate

# Install Flask
pip install flask

# Run the app
python app.py
EOF