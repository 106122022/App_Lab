from flask import Flask, render_template, request, jsonify
import sqlite3

app = Flask(__name__)

def init_db():
    with sqlite3.connect('visits.db') as conn:
        conn.execute('''CREATE TABLE IF NOT EXISTS visit_count (
            id INTEGER PRIMARY KEY,
            count INTEGER DEFAULT 0
        )''')
        conn.execute('INSERT OR IGNORE INTO visit_count (id, count) VALUES (1, 0)')

@app.route('/')
def index():
    with sqlite3.connect('visits.db') as conn:
        conn.execute('UPDATE visit_count SET count = count + 1 WHERE id = 1')
        count = conn.execute('SELECT count FROM visit_count WHERE id = 1').fetchone()[0]
    return render_template('index.html', count=count)

@app.route('/calculate', methods=['POST'])
def calculate():
    data = request.json
    expr = data.get('expression', '')
    try:
        # Safe eval: only numbers and operators
        allowed = set("0123456789+-*/(). ")
        if not set(expr).issubset(allowed):
            return jsonify({'error': 'Invalid input'}), 400
        result = eval(expr)
        return jsonify({'result': result})
    except:
        return jsonify({'error': 'Error in calculation'}), 400

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
