#!/bin/bash

# Create project structure
mkdir -p calculator_site/templates
mkdir -p calculator_site/static
cd calculator_site

# app.py
cat <<'EOF' > app.py
from flask import Flask, render_template, request, jsonify
import sqlite3

app = Flask(__name__)

def init_db():
    with sqlite3.connect('visits.db') as conn:
        conn.execute('''CREATE TABLE IF NOT EXISTS visit_count (
            id INTEGER PRIMARY KEY,
            count INTEGER DEFAULT 0
        )''')
        conn.execute('INSERT OR IGNORE INTO visit_count (id, count) VALUES (1, 0)')

@app.route('/')
def index():
    with sqlite3.connect('visits.db') as conn:
        conn.execute('UPDATE visit_count SET count = count + 1 WHERE id = 1')
        count = conn.execute('SELECT count FROM visit_count WHERE id = 1').fetchone()[0]
    return render_template('index.html', count=count)

@app.route('/calculate', methods=['POST'])
def calculate():
    data = request.json
    expr = data.get('expression', '')
    try:
        # Safe eval: only numbers and operators
        allowed = set("0123456789+-*/(). ")
        if not set(expr).issubset(allowed):
            return jsonify({'error': 'Invalid input'}), 400
        result = eval(expr)
        return jsonify({'result': result})
    except:
        return jsonify({'error': 'Error in calculation'}), 400

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
EOF

# index.html
cat <<'EOF' > templates/index.html
<!DOCTYPE html>
<html>
<head>
    <title>Flask Calculator</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
</head>
<body>
    <div class="container">
        <h1>Calculator</h1>
        <div class="calculator">
            <input type="text" id="display" readonly>
            <div class="buttons">
                <button onclick="append('1')">1</button>
                <button onclick="append('2')">2</button>
                <button onclick="append('3')">3</button>
                <button onclick="append('+')">+</button>

                <button onclick="append('4')">4</button>
                <button onclick="append('5')">5</button>
                <button onclick="append('6')">6</button>
                <button onclick="append('-')">-</button>

                <button onclick="append('7')">7</button>
                <button onclick="append('8')">8</button>
                <button onclick="append('9')">9</button>
                <button onclick="append('*')">*</button>

                <button onclick="append('0')">0</button>
                <button onclick="append('.')">.</button>
                <button onclick="clearDisplay()">C</button>
                <button onclick="append('/')">/</button>

                <button onclick="calculate()" class="equal">=</button>
            </div>
        </div>
        <p>🔢 Page visited {{ count }} times.</p>
    </div>
    <script src="{{ url_for('static', filename='script.js') }}"></script>
</body>
</html>
EOF

# style.css
cat <<'EOF' > static/style.css
body {
    font-family: Arial, sans-serif;
    background-color: #eaeaea;
    padding: 30px;
    text-align: center;
}

.container {
    background: white;
    padding: 20px;
    max-width: 320px;
    margin: auto;
    border-radius: 10px;
    box-shadow: 0 0 10px #ccc;
}

.calculator {
    margin-top: 20px;
}

#display {
    width: 100%;
    height: 40px;
    font-size: 20px;
    text-align: right;
    padding: 5px;
    margin-bottom: 10px;
}

.buttons button {
    width: 22%;
    padding: 15px;
    font-size: 18px;
    margin: 1%;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    background-color: #f0f0f0;
}

.equal {
    width: 94%;
    background-color: #4CAF50;
    color: white;
}
EOF

# script.js
cat <<'EOF' > static/script.js
let display = document.getElementById("display");

function append(val) {
    display.value += val;
}

function clearDisplay() {
    display.value = "";
}

function calculate() {
    fetch('/calculate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ expression: display.value })
    })
    .then(response => response.json())
    .then(data => {
        if (data.result !== undefined) {
            display.value = data.result;
        } else {
            display.value = 'Error';
        }
    });
}
EOF

# Done
echo "✅ Flask calculator project created in 'calculator_site/'"
echo ""
echo "👉 To run:"
echo "   cd calculator_site"
echo "   python3 -m venv venv"
echo "   source venv/bin/activate"
echo "   pip install Flask"
echo "   python app.py"
echo ""
echo "🌐 Open in browser: http://127.0.0.1:5000"
