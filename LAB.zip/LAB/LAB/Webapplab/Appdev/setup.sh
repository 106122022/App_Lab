#!/bin/bash

APP_NAME="TextileShopApp"
PACKAGE_DIR="com/example/textileshopapp"
RES_DIR="$APP_NAME/app/src/main/res"
JAVA_DIR="$APP_NAME/app/src/main/java/$PACKAGE_DIR"

# Create folder structure
mkdir -p $JAVA_DIR
mkdir -p $RES_DIR/layout
mkdir -p $RES_DIR/drawable
mkdir -p $RES_DIR/menu

# Create Java files
cat > $JAVA_DIR/MainActivity.java << 'EOF'
package com.example.textileshopapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView navView = findViewById(R.id.bottom_nav);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();

        navView.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;
            switch (item.getItemId()) {
                case R.id.nav_home: selectedFragment = new HomeFragment(); break;
                case R.id.nav_products: selectedFragment = new ProductsFragment(); break;
                case R.id.nav_contact: selectedFragment = new ContactFragment(); break;
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, selectedFragment).commit();
            return true;
        });
    }
}
EOF

cat > $JAVA_DIR/HomeFragment.java << 'EOF'
package com.example.textileshopapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;

public class HomeFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }
}
EOF

cat > $JAVA_DIR/ProductsFragment.java << 'EOF'
package com.example.textileshopapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;

public class ProductsFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_products, container, false);
    }
}
EOF

cat > $JAVA_DIR/ContactFragment.java << 'EOF'
package com.example.textileshopapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;

public class ContactFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_contact, container, false);
    }
}
EOF

# Layout files
cat > $RES_DIR/layout/activity_main.xml << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:orientation="vertical"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <FrameLayout
        android:id="@+id/fragment_container"
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:layout_weight="1"/>

    <com.google.android.material.bottomnavigation.BottomNavigationView
        android:id="@+id/bottom_nav"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        app:menu="@menu/bottom_nav_menu"/>
</LinearLayout>
EOF

cat > $RES_DIR/layout/fragment_home.xml << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:gravity="center">
    <TextView android:text="Home" android:layout_width="wrap_content" android:layout_height="wrap_content"/>
</FrameLayout>
EOF

cat > $RES_DIR/layout/fragment_products.xml << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:gravity="center">
    <TextView android:text="Products" android:layout_width="wrap_content" android:layout_height="wrap_content"/>
</FrameLayout>
EOF

cat > $RES_DIR/layout/fragment_contact.xml << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:gravity="center">
    <TextView android:text="Contact Us" android:layout_width="wrap_content" android:layout_height="wrap_content"/>
</FrameLayout>
EOF

# Menu file
cat > $RES_DIR/menu/bottom_nav_menu.xml << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<menu xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:id="@+id/nav_home" android:title="Home" android:icon="@android:drawable/ic_menu_view"/>
    <item android:id="@+id/nav_products" android:title="Products" android:icon="@android:drawable/ic_menu_agenda"/>
    <item android:id="@+id/nav_contact" android:title="Contact" android:icon="@android:drawable/ic_menu_call"/>
</menu>
EOF

# AndroidManifest
cat > $APP_NAME/app/src/main/AndroidManifest.xml << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.example.textileshopapp">

    <application
        android:label="TextileShopApp"
        android:icon="@mipmap/ic_launcher"
        android:theme="@style/Theme.MaterialComponents.DayNight.DarkActionBar">
        <activity android:name=".MainActivity">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>
    </application>
</manifest>
EOF

echo "✅ TextileShopApp structure created."
