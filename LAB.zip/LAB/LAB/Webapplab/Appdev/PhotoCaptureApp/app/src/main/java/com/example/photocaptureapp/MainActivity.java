package com.example.photocaptureapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import java.util.LinkedList;

public class MainActivity extends AppCompatActivity {

    private static final int CAMERA_REQUEST_CODE = 100;
    private LinkedList<Bitmap> photoHistory = new LinkedList<>();
    private ImageView imageView;
    private Button takePhotoButton, showHistoryButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        takePhotoButton = findViewById(R.id.takePhotoButton);
        showHistoryButton = findViewById(R.id.showHistoryButton);

        takePhotoButton.setOnClickListener(v -> {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent, CAMERA_REQUEST_CODE);
        });

        showHistoryButton.setOnClickListener(v -> {
            if (!photoHistory.isEmpty()) {
                StringBuilder debugText = new StringBuilder("Displaying most recent photo...");
                imageView.setImageBitmap(photoHistory.getFirst());
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            imageView.setImageBitmap(photo);
            photoHistory.addFirst(photo);
            if (photoHistory.size() > 3) photoHistory.removeLast();
        }
    }
}
