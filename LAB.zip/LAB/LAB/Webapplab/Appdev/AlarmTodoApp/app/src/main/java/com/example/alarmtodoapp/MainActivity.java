package com.example.alarmtodoapp;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    private EditText taskInput;
    private TimePicker timePicker;
    private LinearLayout taskListLayout;
    private AlarmManager alarmManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        taskInput = findViewById(R.id.taskInput);
        Button addButton = findViewById(R.id.addButton);
        timePicker = findViewById(R.id.timePicker);
        taskListLayout = findViewById(R.id.taskListLayout);

        alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        addButton.setOnClickListener(v -> {
            String task = taskInput.getText().toString();
            if (!task.isEmpty()) {
                addTaskToList(task);
                setAlarm(task);
                taskInput.setText("");
            }
        });
    }

    private void addTaskToList(String task) {
        TextView taskView = new TextView(this);
        taskView.setText("🔔 " + task);
        taskListLayout.addView(taskView);
    }

    private void setAlarm(String task) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, timePicker.getHour());
        calendar.set(Calendar.MINUTE, timePicker.getMinute());
        calendar.set(Calendar.SECOND, 0);

        Intent intent = new Intent(this, AlarmReceiver.class);
        intent.putExtra("task", task);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, new Random().nextInt(), intent, PendingIntent.FLAG_IMMUTABLE);
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
    }
}
