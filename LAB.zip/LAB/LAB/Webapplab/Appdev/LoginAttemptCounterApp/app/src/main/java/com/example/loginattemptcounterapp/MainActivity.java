package com.example.loginattemptcounterapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput, passwordInput;
    private TextView successCountText, failureCountText;
    private SharedPreferences prefs;

    private final String CORRECT_USERNAME = "admin";
    private final String CORRECT_PASSWORD = "1234";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        Button loginButton = findViewById(R.id.loginButton);
        successCountText = findViewById(R.id.successCount);
        failureCountText = findViewById(R.id.failureCount);

        prefs = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        updateUI();

        loginButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString();
            String password = passwordInput.getText().toString();

            SharedPreferences.Editor editor = prefs.edit();
            int successCount = prefs.getInt("successCount", 0);
            int failureCount = prefs.getInt("failureCount", 0);

            if (username.equals(CORRECT_USERNAME) && password.equals(CORRECT_PASSWORD)) {
                editor.putInt("successCount", successCount + 1);
            } else {
                editor.putInt("failureCount", failureCount + 1);
            }

            editor.apply();
            updateUI();
        });
    }

    private void updateUI() {
        successCountText.setText("Successful Logins: " + prefs.getInt("successCount", 0));
        failureCountText.setText("Unsuccessful Logins: " + prefs.getInt("failureCount", 0));
    }
}
