package com.example.authtrackerapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput, passwordInput;
    private TextView successText, failureText;
    private SharedPreferences prefs;

    private final String CORRECT_USERNAME = "user";
    private final String CORRECT_PASSWORD = "pass";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        Button loginButton = findViewById(R.id.loginButton);
        successText = findViewById(R.id.lastSuccess);
        failureText = findViewById(R.id.lastFailure);

        prefs = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        loadLoginDetails();

        loginButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString();
            String password = passwordInput.getText().toString();
            SharedPreferences.Editor editor = prefs.edit();
            String currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

            if (username.equals(CORRECT_USERNAME) && password.equals(CORRECT_PASSWORD)) {
                editor.putString("lastSuccess", currentTime);
            } else {
                editor.putString("lastFailure", currentTime);
            }

            editor.apply();
            loadLoginDetails();
        });
    }

    private void loadLoginDetails() {
        successText.setText("Last Success: " + prefs.getString("lastSuccess", "Never"));
        failureText.setText("Last Failure: " + prefs.getString("lastFailure", "Never"));
    }
}
