<link rel="stylesheet" href="css/style.css">
<div class="container">
    <h2>Register</h2>
    <form method="POST">
        <input name="username" required placeholder="Username">
        <input type="password" name="password" required placeholder="Password">
        <button type="submit">Register</button>
    </form>
    <a href="index.php">← Back</a>
    <a href="login.php">Already have an account? Login</a>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $users = file_exists('data/users.txt') ? file('data/users.txt', FILE_IGNORE_NEW_LINES) : [];
    foreach ($users as $user) {
        list($u, $p) = explode('|', $user);
        if ($u === $_POST['username']) {
            echo "<div class='error'>Username taken.</div>";
            exit;
        }
    }

    $newUser = $_POST['username'] . '|' . password_hash($_POST['password'], PASSWORD_BCRYPT) . "\n";
    file_put_contents('data/users.txt', $newUser, FILE_APPEND);
    echo "<div class='notice'>Registered successfully. <a href='login.php'>Login</a></div>";
}
?>
</div>
