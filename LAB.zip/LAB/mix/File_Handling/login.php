<?php
require 'includes/auth.php';
?>

<link rel="stylesheet" href="css/style.css">
<div class="container">
    <h2>Login</h2>
    <form method="POST">
        <input name="username" required placeholder="Username">
        <input type="password" name="password" required placeholder="Password">
        <button type="submit">Login</button>
    </form>
    <a href="index.php">← Back</a>
    <a href="register.php">New user? Register here</a>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $users = file_exists('data/users.txt') ? file('data/users.txt', FILE_IGNORE_NEW_LINES) : [];

    foreach ($users as $user) {
        list($u, $p) = explode('|', $user);
        if ($u === $_POST['username'] && password_verify($_POST['password'], $p)) {
            $_SESSION['user_id'] = $u;
            header("Location: upload.php");
            exit;
        }
    }

    echo "<div class='error'>Invalid credentials.</div>";
}
?>
</div>
