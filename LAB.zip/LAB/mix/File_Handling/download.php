<?php
require 'includes/auth.php';

$id = $_GET['id'] ?? -1;
$lines = file('data/files.txt', FILE_IGNORE_NEW_LINES);
if (!isset($lines[$id])) die("Invalid file ID");

list($name, $path, $category, $owner, $filePassword) = explode('|', $lines[$id]);

echo "<link rel='stylesheet' href='css/style.css'><div class='container'>";

switch ($category) {
    case 'public':
        break;

    case 'private':
        if (!isLoggedIn()) die("<div class='error'>Login required.</div><a href='login.php'>Login</a>");
        break;

    case 'restricted':
        if (!isLoggedIn()) die("<div class='error'>Login required.</div><a href='login.php'>Login</a>");
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (password_verify($_POST['file_password'], $filePassword)) break;
            else die("<div class='error'>Incorrect password.</div><a href='download.php?id=$id'>Try Again</a>");
        } else {
            echo "<h2>Restricted File</h2>";
            echo "<form method='POST'><input type='password' name='file_password' required placeholder='Enter password'>";
            echo "<button type='submit'>Access</button></form><a href='index.php'>← Back</a>";
            exit;
        }
        break;
}

if (file_exists($path)) {
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($path) . '"');
    readfile($path);
    exit;
} else {
    echo "<div class='error'>File not found.</div>";
}
echo "</div>";
