<?php
require 'includes/auth.php';
requireLogin();
?>

<link rel="stylesheet" href="css/style.css">
<div class="container">
    <h2>Upload File</h2>

    <form method="POST" enctype="multipart/form-data">
        <input type="file" name="file" required>
        <select name="category">
            <option value="public">Public</option>
            <option value="private">Private</option>
            <option value="restricted">Private (Restricted)</option>
        </select>
        <input name="file_password" placeholder="Password for restricted (optional)">
        <button type="submit">Upload</button>
    </form>
    <a href="index.php">← Back to Home</a>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category = $_POST['category'];
    $username = getCurrentUsername();
    $filename = basename($_FILES['file']['name']);
    $uploadDir = "files/$category/";
    $targetPath = $uploadDir . $filename;

    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

    $filePassword = ($category === 'restricted' && !empty($_POST['file_password'])) 
        ? password_hash($_POST['file_password'], PASSWORD_BCRYPT) 
        : '';

    if (move_uploaded_file($_FILES['file']['tmp_name'], $targetPath)) {
        $record = "$filename|$targetPath|$category|$username|$filePassword\n";
        file_put_contents('data/files.txt', $record, FILE_APPEND);
        echo "<div class='notice'>File uploaded successfully!</div>";
    } else {
        echo "<div class='error'>Failed to upload file.</div>";
    }
}
?>
</div>
