<?php require 'includes/auth.php'; ?>

<link rel="stylesheet" href="css/style.css">
<div class="container">
    <h2>Available Files</h2>

    <?php if (!isLoggedIn()): ?>
        <a href="login.php">Login</a> |
        <a href="register.php">New user? Register</a>
    <?php else: ?>
        <a href="upload.php">Upload File</a> |
        <a href="logout.php">Logout</a>
    <?php endif; ?>

    <hr>

    <?php
    $files = file_exists('data/files.txt') ? file('data/files.txt', FILE_IGNORE_NEW_LINES) : [];
    foreach ($files as $index => $line) {
        list($name, , $category) = explode('|', $line);
        echo "<div>$name ($category) - <a href='download.php?id=$index'>Download</a></div>";
    }
    ?>
</div>
